#include <iostream>
#include <string>
using namespace std;
class Employee
{
    public:
        Employee()
        {
            salary=0;
            first_name="najeeb";
            last_name="ahmed";
        }
        void set_first_name(string firstname)
        {
            first_name=firstname;
        }
        string get_first_name()
        {
            return first_name;
        }
        void set_last_name(string lastname)
        {
            last_name=lastname;
        }
        string get_last_name()
        {
            return last_name;
        }
        void set_salary(double amount)
        {
            if (amount<0)
            {
                amount=0.0;
            }
           amount=(amount*12);
           salary=amount;
        }

        double get_salary()
        {
            return salary;
        }
        double rise_salary()
        {
            double a;
          a=salary*.1;
          salary=a+salary;
            return salary;
        }
     private:
            double salary;
            string first_name;
            string last_name;
};
int main()
{
    string firstname,lastname;
    double amount;
    Employee person1;
    cout<<"write your first name and second name"<<endl;
    cin>>firstname>>lastname;
    cout<<firstname<<" "<<lastname<<endl;
    person1.set_first_name(firstname);
    cout<<person1.get_first_name();
    person1.set_last_name(lastname);
    cout<<person1.get_last_name()<<endl;
    person1.set_salary(2300);
    cout<<"your yearly salary is"<<endl;
    cout<<person1.get_salary()<<endl;
    cout<<"your yearly salary with bonus is "<<endl;
    cout<<person1.rise_salary();
    return 0;
}
