#include <iostream>

using namespace std;
class Account
{
    public:
        Account(double inital_balance)
        {
            balance = inital_balance;
        }
        void credit(double amount)
        {
          cout<<"enter  the amount you want to withdraw feom account"<<endl;
          cin>>amount;
          if (amount>balance)
          {
              cout<<"debit amount exceeed the balance"<<endl;
          }
            else
            {
                balance=balance-amount;
                cout<<balance;
            }
        }
        double getbalance()
        {
            return balance;
        }
     private:
            double balance;

};
int main()
{
    Account account1(45);
    account1.credit(45);
    cout<<"Now your Account balance is "<<account1.getbalance()<<'\n';
    Account account2(2323);
    account2.credit(2323);
    cout<<"Now Your Account balance is "<<account2.getbalance()<<'\n';
    return 0;
}
