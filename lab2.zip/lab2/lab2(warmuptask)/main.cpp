#include <iostream>

using namespace std;
class Account
{
    public:
        Account(double inital_balance)
        {
            balance = inital_balance;
        }
        void credit(double amount)
        {
          balance=0;
        }
        double getbalance()
        {
            return balance;
        }
     private:
            double balance;

};
int main()
{
    Account account1(45);
    cout<<"Account balance is "<<account1.getbalance()<<'\n';
    Account account2(2323);
    cout<<"Account balance is "<<account2.getbalance()<<'\n';
    return 0;
}
