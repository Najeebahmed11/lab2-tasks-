#include <iostream>
#include <string>
using namespace std;
class Invoice
{
    public:
        Invoice()
        {
            price=0;
            quantity=0;
            part_number="r";
            description="x";
        }
        void set_part_number(string partnumber)
        {
            part_number=partnumber;
        }
        string get_part_number()
        {
            return part_number;
        }
        void set_description(string des)
        {
            description=des;
        }
        string get_description()
        {
            return description;
        }
        void set_price(double amount)
        {
            price=amount;
        }

        double get_price()
        {
            return price;
        }
        void set_quantity(double amount)
        {
           quantity=amount;
        }
        double get_quantity()
        {
           return quantity;
        }
        void set_invoiceamount(double amount,double amount1)
        {
            invoiceamount=amount*amount1;
        }
        double get_invoiceamount()
        {
            return invoiceamount;
        }
     private:
            double invoiceamount;
            double price;
            int quantity;
            string part_number;
            string description;
};
int main()
{
    string partnumber,des;
    double amount=2300;
    double amount1=4;
    Invoice person;
    cout<<"write your part number and description??"<<endl;
    cin>>partnumber>>des;
    cout<<partnumber<<"   "<<des<<endl;
    person.set_part_number(partnumber);
    cout<<person.get_part_number();
    person.set_description(des);
    cout<<person.get_description()<<endl;
    person.set_price(amount);
    cout<<"your price is"<<endl;
    cout<<person.get_price()<<endl;
    person.set_quantity(amount1);
    cout<<"your quantity is "<<endl;
    cout<<person.get_quantity()<<endl;
    person.set_invoiceamount(amount,amount1);
    cout<<"your invoice amount is"<<endl;
    cout<<person.get_invoiceamount()<<endl;
    return 0;
}
